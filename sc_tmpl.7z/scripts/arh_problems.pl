#!c:\perl\bin\perl.exe

use DBI;
use IO;
use CGI qw(:standard);
use CGI::Cookie;
use CGI::Carp  qw(fatalsToBrowser);
use POSIX;

require 'construct_dt_and_classify_one_sample.pl';
require 'common_func.pl';
use vars qw($request $db $DirTemplates $incgi %cookies %ENV);


read_config();
connect_db();

#���� �� ���������
$sth = $db->prepare("select def_lng from const");
$sth->execute;
@row = $sth->fetchrow_array;
$lng_def=$row[0];
$sth->finish;

fcgi_init();

main_cik:
while(next_request()) {

   $db->commit;
  
   CGI::_reset_globals;
   $incgi = new CGI;
    
   #� ����� �������� cookies
   %cookies = parse CGI::Cookie($ENV{'HTTP_COOKIE'});

   GetLanguage(\$id_lng,\$cookie1); 

   $id_user=authenticate_process("true");
   next main_cik if ($id_user.'' eq 'end');

   $prb = $incgi->param("id_prb")+0;

   if ($prb) {
      $fname = "cond_problem_$id_lng.html";
   } else {
      $cookie2 = undef;

      $cur_tm = $incgi->param("id_tm")+0;
      if (!$cur_tm) {
         $cur_tm = $cookies{"id_tm"};
         $find_substr = $cur_tm =~ m/\s*id_tm\s*=\s*(\w*)/;
         if ($find_substr) {$cur_tm = "$1"+0;}
         else {$cur_tm=0;}
      } else {
         $scr_nm = $ENV{"SCRIPT_NAME"};
         $cookie2 = new CGI::Cookie(-name=>"id_tm",-value=>"$cur_tm",-path=>"$scr_nm");
      }

      $fname = "tm_problems_$id_lng.html";
   }

   #������� ������ � ������� ��� ������
   $string_template='';
   read_file("$DirTemplates\\$fname",\$string_template);

   #���������� $include_files(x)
   include_files(\$string_template);
   if ($prb) {
      insert_problem_subjs(\$string_template,$prb,$id_user,$id_lng);
      insert_problem_atr(\$string_template,$prb,$lng_def,$id_lng,$id_user);
   } else {
      #���������� $insert_tema
      $cur_tm=insert_tema(\$string_template,$cur_tm,$lng_def,$id_lng,$id_user);
	  $tree = $incgi->param("tree")+0;
	  $classify = $incgi->param("classify")+0;
      #���������� $insert_problems
      insert_problems(\$string_template,$cur_tm,$lng_def,$id_lng,$id_user,$classify);
	  if ($tree==1){
		#���������� $construct_tree_alhoritm
		construct_tree_alhoritm(\$string_template);
		#���������� $last_build_tree
	    last_build_tree(\$string_template);
		$tree = 0;
		print $incgi->redirect( -URL => "/cgi-bin/arh_problems.pl?tree=0");
	  }
	  elsif ($classify){
		#���������� $decision_tree_alhoritm
		decision_tree_alhoritm(\$string_template,$cur_tm,$lng_def,$id_lng,$id_user);
	  }else{
		my $str = " ";
	    set_helper(\$string_template,$str);
	  }
	  #���������� $last_build_tree
	  last_build_tree(\$string_template);
   }
   login_info(\$string_template,$id_user);


   
   #���������� $current_page
   current_page(\$string_template);
		
   #$string_template =~ s/<!--.*?-->//sg;
  
   print header(-charset=>"Windows-1251",
               -cookie=>[$cookie1,$cookie2],
               -cache_control=>"no-cached",
               -pragma=>"no-cache"
               );
   print "$string_template";

}

print "\n";
$db->disconnect;
POSIX:_exit(0);

#------------------------
#      Functions
#------------------------
sub set_helper{
	my($text,$str) = @_;
	$$text =~ s/\$helper/$str/ig;
}


sub last_build_tree{
	my($text) = @_;
	my $sth=0;
	$query=<<SQL;
       select max(date_time) from decision_history
SQL
              
    $sth = $db->prepare($query);
    $sth->execute;
    $last_dt=$sth->fetchrow_array;
	$$text =~ s/\$last_build_tree/$last_dt/ig;
}

sub construct_tree_alhoritm{
    my($text) = @_;
	construct_dt();
	$$text =~ s/\$helper//ig;
}


sub decision_tree_alhoritm
{
	my($text,$cur_tm,$id_lngd,$id_lngc,$id_user) = @_;
	#�������� ������������
	my $user_query = <<SQL;
	select solve_cnt from authors
		where id_publ = '$id_user'
SQL
	my $st = $db->prepare($user_query);
    $st->execute;
	my $solve_cnt = $st->fetchrow_array;
			$user_name="<div>$id_user</div>";
			my $query=<<SQL;
			select pr.id_prb
			 from tm_prb tp inner join problems pr on tp.id_prb=pr.id_prb 
				  inner join statistica st on st.id_prb=pr.id_prb
				  inner join problems_lng pl on pl.id_prb=pr.id_prb and pl.id_lng='$id_lngc'
			 where st.id_rsl=0 and tp.id_tm=$cur_tm 
			 order by tp.order_pos, pl.name
SQL
    my $sth = $db->prepare($query);
    $sth->execute;
	my @task = ();
	my $i = 0;
	while ( my $idtask = $sth->fetchrow_array) {
	    $idtask =~ s/\s//g; 
		$task[$i]=$idtask;
		$i++;
	}
    
	#���� ������� ����������
	if($id_user == 0){
	    my $help = "<div id='help' style='background-color: #fef0b3; border: solid 1px #cc0075; width:200px; color:#cc0075; margin-bottom: 5px; text-align: center; padding:5px'>������� ����������, ������� � ������� ��� �����������������
		            <br>
					<input type='button' value='�������' onclick='CloseHelp()'></input> 
					</div><div></div>";
	   $$text =~ s/\$helper/$help/ig;
	   my $k = 0;
		foreach (@task){
			$$text =~ s/\$class$task[$k]task/ - /ig;
			$k++;
		}
	}elsif ($solve_cnt > -10){
		my $add_task = 10 + $solve_cnt;
		my $help = "<div id='help' style='background-color: #fef0b3; border: solid 1px #cc0075; width:200px; color:#cc0075; margin-bottom: 5px; text-align: center; padding:5px'>�� ������ ������� ���� �����, ������ ��� $add_task ����� ��� ��������� ��������
		            <br>
					<input type='button' value='�������' onclick='CloseHelp()'></input> 
					</div><div></div>";
		$$text =~ s/\$helper/$help/ig;
		my $k = 0;
		foreach (@task){
			$$text =~ s/\$class$task[$k]task/ - /ig;
			$k++;
		}
	}else{
		my @classes = classify_tasks($id_user,@task);
		my $finalstr = join(' ',@classes);
		my $j=0;
		foreach(@classes){
			if ($classes[$j] == 3){
				$$text =~ s/\$class$task[$j]task/������/ig;
			}elsif($classes[$j] == 2){
				$$text =~ s/\$class$task[$j]task/������� ���������/ig;
			}elsif($classes[$j] == 1){
				$$text =~ s/\$class$task[$j]task/�������/ig;
			}elsif($classes[$j] == 0){
				$$text =~ s/\$class$task[$j]task/��� ������/ig;
			}else{
				$$text =~ s/\$class$task[$j]task/������� ����������/ig;
			}
			$j++;
		}
		$$text =~ s/\$helper//ig;
	}
}


sub insert_tema
{
  my($text,$cur_tm,$id_lngd,$id_lngc,$user) = @_;
  my $query="";
  my $sth=0;
  my @row=(),@row1=(),$is_new_prb;
  my $add_info='$nnlist';
  my $cur_pg=$ENV{"SCRIPT_NAME"};
  my $end_ierarh=$cur_tm;
  my $tmp1=0;
  my $tmp2=0;
  my $tmp3=0;
  my ($img_plus) = $$text =~ /\$node_plus\s*=\s*\{(.*?)\}/s;
  my ($img_minus) = $$text =~ /\$node_minus\s*=\s*\{(.*?)\}/s;
  my ($img_open) = $$text =~ /\$node_open\s*=\s*\{(.*?)\}/s;
  my ($img_close) = $$text =~ /\$node_close\s*=\s*\{(.*?)\}/s;

  my $smroot="is null";
  my $rez_tm=$cur_tm;

  if ($cur_tm > 0) {
     $query=<<SQL;
       select distinct CASE
              WHEN (t.small_root IS NULL) THEN t.id_tm
              ELSE t.small_root END, t.id_tm
       from tema t inner join get_subjs_user($user) gsu on t.id_tm=gsu.id_tm
       where t.small_root = $cur_tm or t.id_tm = $cur_tm
SQL
              
     $sth = $db->prepare($query);
     $sth->execute;
     @row=$sth->fetchrow_array;
     if ($row[0]>0) {
        @row1=$sth->fetchrow_array;
     } else {
        $rez_tm=-1; 
     }
     $sth->finish;
     
     if ($row1[0]>0) { $smroot=" =$cur_tm "; }
     else {
        if ($row[0]>0 && $row[0]!=$cur_tm) { 
           $smroot=" =$row[0] ";
           $end_ierarh = $row[0];
        } else {
           $smroot="is null";
        }
     }
  }

  if ($smroot ne "is null") {
    my $cur_node=$end_ierarh;
    my @levels=();
    my $lev_cnt=0;

    do {
  #������ ��� ��������� ��������(� ����� ����)
  $query="select name, small_root from tema,tema_lng "
  ."where id_lng='$id_lngc' and tema.id_tm=tema_lng.id_tm and tema.id_tm = $cur_node "
  ."union select name, small_root from tema, tema_lng "
  ."where id_lng='$id_lngd' and tema.id_tm=tema_lng.id_tm and tema.id_tm = $cur_node "
  ."and tema.id_tm not in (select id_tm from tema_lng where id_lng='$id_lngc' and tema.id_tm = $cur_node)";
       $sth = $db->prepare($query);
       $sth->execute;
       @row=$sth->fetchrow_array;
       $sth->finish;
       $levels[2*$lev_cnt]=$cur_node;
       $row[0] =~ s/ *\Z//;
       $levels[2*$lev_cnt+1]=$row[0];
       $lev_cnt++;
       $cur_node=$row[1];
    } while ($cur_node ne "");
    
    $levels[2*$lev_cnt]=-1;
    ($levels[2*$lev_cnt+1]) = $$text =~ /\$main_root\s*=\s*\{(.*?)\}/s;
    $lev_cnt++;

    for (my $i=$lev_cnt-2;$i>=0;$i--) {
       $tmp1=$levels[2*($i+1)];
       $tmp2=$img_minus.$levels[2*$i+1];

     if ($cur_tm == $levels[2*$i]) {
        $tmp3 = "<li><a class=\"tm_cur\" href=$cur_pg?id_tm=$tmp1>$tmp2</a>";
     } else {
        $tmp3 = "<li><a href=$cur_pg?id_tm=$tmp1>$tmp2</a>";
     }
       $add_info =~s/\$nnlist/$tmp3<ul class="Subj">\$nnlist<\/ul>/;
    }

#    $add_info =~s/\$nnlist/<ul class="Subj">\$nnlist<\/ul>/;
  }

  #�������� ������� � ������ ����
  $query=<<SQL;
  select distinct t.id_tm, tl.name, t.prb_cnt, t.order_pos
     from get_subjs_user($user) gsu inner join tema t on gsu.id_tm=t.id_tm
         inner join tema_lng tl on t.id_tm=tl.id_tm and id_lng='$id_lngc'
     where t.small_root $smroot 
     order by t.order_pos, tl.name
SQL
  
  $sth = $db->prepare($query);
  $sth->execute;
  $tmp3="";
  while (@row = $sth->fetchrow_array) {

     foreach (@row) {
          #������ ������� � ����� ����
        $_ =~ / *\Z/;
        $_ = "$`";
        #���� ���� �����, �� ������� ��� �� ������� ������
        if ($_ eq "") {$_ =  "&nbsp;";}
     }


     if ($cur_tm == $row[0]) {
        $tmp3 .= "<li><a class=\"tm_cur\" href=$cur_pg?id_tm=$row[0]>$img_open$row[1] ($row[2])</a>\n";
     } else {
     if ($row[2]==-1) {
        $tmp3 .= "<li><a href=$cur_pg?id_tm=$row[0]>$img_plus$row[1]</a>\n";
     } else {
        $tmp3 .= "<li><a href=$cur_pg?id_tm=$row[0]>$img_close$row[1] ($row[2])</a>\n";
     }}
  }

  $sth->finish;

  $query="select max(g.f_create_prb) from get_groups_user($user) ggu inner join groups g on ggu.id_grp=g.id_grp";
  $sth = $db->prepare($query);
  $sth->execute;
  ($is_new_prb) = $sth->fetchrow_array;
  $sth->finish;
  if (!$is_new_prb) {
     $query="select max(f_create_prb) from all_subjs_user($user,0,0)";
     $sth = $db->prepare($query);
     $sth->execute;
     ($is_new_prb) = $sth->fetchrow_array;
     $sth->finish;
  }

  $$text =~ s/<!--start_new_problem-->(.*?)<!--finish_new_problem-->/$is_new_prb?$1:''/esig;

  $add_info =~s/\$nnlist/$tmp3/;
  $$text =~ s/\$insert_tema/$add_info/ig;

  return $rez_tm;
}

sub insert_problems
{
  my($text,$cur_tm,$id_lngd,$id_lngc,$user,$classify) = @_;

  my @status_prb,$hidden_prb='',$ord_pos,$i;
  
  ($status_prb[0]) = $$text =~ /\$notsubmit\s*=\s*\{(.*?)\}/s;
  ($status_prb[1]) = $$text =~ /\$solve\s*=\s*\{(.*?)\}/s;
  ($status_prb[2]) = $$text =~ /\$notsolve\s*=\s*\{(.*?)\}/s;

  my $query=<<SQL;
  select pr.id_prb,pl.name,st.cnt,pr.subms_cnt,pr.asolv_cnt,pr.id_creator, 
     (select case when min(id_rsl)=0 and count(id_rsl)>0 then 1 
                  when count(id_rsl)=0 then 0 
                  else 2 end
       from status where id_publ=$user and id_prb=pr.id_prb ), pr.hardlevel, tp.order_pos
     from tm_prb tp inner join problems pr on tp.id_prb=pr.id_prb 
          inner join statistica st on st.id_prb=pr.id_prb
          inner join problems_lng pl on pl.id_prb=pr.id_prb and pl.id_lng='$id_lngc'
     where st.id_rsl=0 and tp.id_tm=$cur_tm 
     order by tp.order_pos, pl.name
SQL

  my $sth = $db->prepare($query);
  $sth->execute;

  my $cur_pg=$ENV{"SCRIPT_NAME"};

  my $add_info="";
  while ( my @row = $sth->fetchrow_array) {
     $i=0;
     foreach (@row) {
          #������ ������� � ����� ����
        $_ =~ / *\Z/;
        $_ = "$`";
        #���� ���� �����, �� ������� ��� �� ������� ������
        if ($_ eq "" && $i!=8) {$_ =  "&nbsp;";}
        $i++;
     }
        if ($row[3]!=0) {
           $accept= int(100*$row[2]/$row[3]);
           $accept = "$accept%";
        } else { $accept="0%"; }

    if ($row[8]) {$ord_pos=$row[8].' - ';}
    else {$ord_pos='';}

    if (($row[5]==$user || $row[4]>0) && !$classify) {    
        $add_info .= "<tr>"
        ."<td align=right><div style='float:left;'>$status_prb[$row[6]]</div><div id='task' style='margin-right:2px;float:right;'>$row[0]</div></td>"
        ."<td><a href=$cur_pg?id_prb=$row[0]>$ord_pos $row[1]</a></td>"
        ."<td align=center><a href=/cgi-bin/statistica.pl?id_prb=$row[0]>$accept</a></td>"
        ."<td align=center>$row[4]</td>"
        ."<td align=center>$row[7]</td>"
        ."</tr>\n";
		$$text =~ s/\$insert_prognoz//ig;
	}elsif(($row[5]==$user || $row[4]>0) && $classify){
	    $row[0] =~ s/\s//ig; 
	    $add_info .= "<tr>"
		."<td align=right><div style='float:left;'>$status_prb[$row[6]]</div><div id='task' style='margin-right:2px;float:right;'>$row[0]</div></td>"
        ."<td><a href=$cur_pg?id_prb=$row[0]>$ord_pos $row[1]</a></td>"
        ."<td align=center><a href=/cgi-bin/statistica.pl?id_prb=$row[0]>$accept</a></td>"
        ."<td align=center>$row[4]</td>"
        ."<td align=center>$row[7]</td>"
		."<td align=center><div id='$row[0]'>\$class$row[0]task</div></td>"
        ."</tr>\n";
		my $prognoz = "<th width='60'>�������</th>";
		$$text =~ s/\$insert_prognoz/$prognoz/ig;
    } else {
       $hidden_prb.="<a href=$cur_pg?id_prb=$row[0] title=\"$row[1]\">$row[0]</a>&nbsp;&nbsp;";
    }
  }

  $sth->finish;

  $$text =~ s/<!--start_hidden_problem-->(.*?)<!--finish_hidden_problem-->/($hidden_prb)?$1:''/esig;
  $$text =~ s/<!--start_show_problems-->(.*?)<!--finish_show_problems-->/($add_info)?$1:''/esig;
  $$text =~ s/\$insert_problems/$add_info/ig;
  $$text =~ s/\$hidden_prb/$hidden_prb/ig;
  #$$text =~ s/\$helper/---/ig;
}

sub insert_problem_atr
{
  my($text,$id_prb,$id_lngd,$id_lngc,$user) = @_;

  my $bl=0,$ts,$ttl;
  my $query,$sth,@row,$f_submit_prb,$f_edit_prb,$o_id_prb;
  my $new_text="",$abs_path="",$fh;

  $o_id_prb=$id_prb;

  $query="select f_submit_prb, f_edit_prb from access_user_prb($user,'.$id_prb.')";
  $sth = $db->prepare($query);
  $sth->execute;
  ($f_submit_prb,$f_edit_prb) = $sth->fetchrow_array;
  $sth->finish;
  
  if ($f_submit_prb>0) {
  
     #������� ����� ������
     $fh = new IO::File;
     $fh->open("< $DirPrbCond\\$id_prb\\$id_lngc\\index.html");

     if ($fh->error != 0) {
        $fh->open("< $DirPrbCond\\$id_prb\\$id_lngd\\index.html");
        $bl=1;
        $id_lngc=$id_lngd;
     }
     while (<$fh>) {
        $new_text .= $_;
     }  
     $fh->close;
  
     #������� body
     if ($new_text =~ m/<\s*body[^>]*?>(.*?)<\s*\/\s*body\s*>/si) {
        $new_text=$1;
     }

     #������� ������������� ���� � ������� �� ����������      (http:\/\/|\/|)
     if ($bl == 0) {
        $abs_path = "$DirVirtualPrb\/$id_prb\/$id_lngc\/";
     } else {
        $abs_path = "$DirVirtualPrb\/$id_prb\/$id_lngd\/";
     }
     $new_text =~ s/(<\s*(?:img|image)\s+.*?src\s*=\s*"?)([^\/"][^>]*?)("?[\s\n>])/$1$abs_path$2$3/sig;
     $new_text =~ s/(<\s*(?:object)\s+.*?data\s*=\s*"?)([^\/"][^>]*?)("?[\s\n>])/$1$abs_path$2$3/sig;
     $new_text =~ s/(<\s*(?:a)\s+.*?href\s*=\s*"?)([^\/"][^>]*?)("?[\s\n>])/$1$abs_path$2$3/sig;
     $new_text =~ s/(<\s*(?:link)\s+.*?href\s*=\s*"?)([^\/"][^>]*?)("?[\s\n>])/$1$abs_path$2$3/sig;

  } else {
     $id_prb=0;
     if ($$text =~ /<!--.*?\$access_denied_prb\s*=\s*\{(.*?)\}.*?-->/is) {
        $new_text=$1;
     }
  }

  #������� �������� ������
  $query="select template_s, title from condition_titles_lng where id_lng='$id_lngc'";
  $sth = $db->prepare($query);
  $sth->execute;
  while (($ts,$ttl) = $sth->fetchrow_array) {
    $new_text=~s/$ts/$ttl/ig;
  }
  $sth->finish;


  $$text =~ s/\$include_cond_prb/$new_text/gi;

  #������� ��������, time limit & memory limit
  if ($bl == 0) {
     $query="select name, author from problems_lng where id_prb=$id_prb and id_lng='$id_lngc'";
  } else {
     $query="select name, author from problems_lng where id_prb=$id_prb and id_lng='$id_lngd'";
  }

  $sth = $db->prepare($query);
  $sth->execute;
  @row = $sth->fetchrow_array;
  $sth->finish;

  $row[0] =~ s/\s*\Z//;
  $$text =~ s/\$problem_name/$row[0]/gi;
  $$text =~ s/\$problem_source/$row[1]/gi;

  $query="select p.time_lim, p.mem_lim, p.id_creator, a.name, p.hardlevel ".
         " from problems p left outer join authors a on p.id_creator=a.id_publ ".
         " where id_prb=$id_prb";
  $sth = $db->prepare($query);
  $sth->execute;
  @row = $sth->fetchrow_array;
  $sth->finish;
  $row[0]=int($row[0]*1000)/1000;
  $row[1]=$row[1]*1;
  if (!$row[2]) {
    $row[2]=-1;
    ($row[3]) = $$text =~ /<!--[\s\n\r]*\$author_undef\s*=\s*\{(.*?)\}.*?-->/is;
  }
                                                                                   
  html_text(\$row[3]);
  $$text =~ s/<!--start_edit_problem-->(.*?)<!--finish_edit_problem-->/($f_edit_prb)?$1:''/esig;

  $$text =~ s/\$time_limit/$row[0]/gi;
  $$text =~ s/\$memory_limit/$row[1]/gi;
  $$text =~ s/\$id_author/$row[2]/gi;
  $$text =~ s/\$author_name/$row[3]/gi;
  $$text =~ s/\$problem_id/$id_prb/gi;
  $$text =~ s/\$add_param/&id_prb=$o_id_prb/ig;
  $$text =~ s/\$hardlevel/$row[4]/ig;

}


#------------------------------------------------------------------------
sub insert_problem_subjs
{
   my ($text,$id_problem,$id_user,$id_lng) = @_;

   my $before,$after,$before0,$after0,$before_p0,$after_p0,$before_p1,$after_p1,$s,$s0,$s1,$sp0,$sp1,$i;
   my $sect_tm='',$sect_tm0='',$sect_prb0='',$sect_prb1='',$query,$sth,$sth1,$i_id_prb,$i_prb_name;
   my $query0,$query1,$ord_pos;

  
   $$text =~ m/<!--start_tm_sect-->(.*?)<!--finish_tm_sect-->/si;
   $before0=$`;
   $sect_tm0=$1;
   $after0=$';

   $sect_tm0 =~ m/<!--start_in_tm-->(.*?)<!--finish_in_tm-->/si;
   $before=$`;
   $sect_tm=$1;
   $after=$';

   $after =~ m/<!--start_other_prb0-->(.*?)<!--finish_other_prb0-->/si;
   $before_p0=$`;
   $sect_prb0=$1;
   $after_p0=$';

   $after_p0 =~ m/<!--start_other_prb1-->(.*?)<!--finish_other_prb1-->/si;
   $before_p1=$`;
   $sect_prb1=$1;
   $after_p1=$';

   $query=<<SQL;
      select tree.id_tm,tl.name
         from get_tree_subj_problem($id_problem,$id_user) tree
            left outer join tema_lng tl on tree.id_tm=tl.id_tm and tl.id_lng='$id_lng'
         order by tree.id_tm0,tree.id_level desc
SQL
   $sth=$db->prepare($query);
   $sth->execute();

   $s1='';
   while (my @row=$sth->fetchrow_array) {
      if ($row[0]) {
         $row[1] =~ s/ *$//m;
         $s=$sect_tm;
         $s =~ s/\$i_id_tm/$row[0]/ig;
         $s =~ s/\$i_tm_name/$row[1]/ig;
         $s1.=$s;

   $query0=<<SQL;
  select id_prb,order_pos,name,pos_in_tm
     from get_near_problems($row[0],$id_problem,'$id_lng',1,3)
SQL

      } else {
         $sth1=$db->prepare($query0);
         $sth1->execute();
         $sp0='';
         $sp1='';
         while ((my @row1=$sth1->fetchrow_array)) {
            $row1[1] =~ s/ *$//m;
            $row1[2] =~ s/ *$//m;
            if ($row1[1]) {$ord_pos=$row1[1].' - ';}
            else {$ord_pos='';}

            if ($row1[3]<0) { $s=$sect_prb0; }
            if ($row1[3]>0) { $s=$sect_prb1; }

            $s =~ s/\$i_id_prb/$row1[0]/ig;
            $s =~ s/\$i_prb_name/$ord_pos $row1[2]/ig;

            if ($row1[3]<0) { $sp0.=$s; }
            if ($row1[3]>0) { $sp1.=$s; }
         }
         $sth1->finish();

         $s0=$before.$s1.$before_p0.$sp0.$before_p1.$sp1.$after_p1;
         $s1='';
         $before0.=$s0;
      }
   }
   $sth->finish();

   $$text=$before0.$after0;


   $$text =~ s/\$id_problem/$id_problem/ig;
}


  