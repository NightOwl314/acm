//---------------------------------------------------------------------------

#ifndef max_substrH
#define max_substrH
int find_max_substr(char *s1, int len1,char *s2, int len2, int *offset1, int *offset2);
int find_common_substr_x(const char *s1, int len1, const char *s2, int len2, int k);
//---------------------------------------------------------------------------
#endif
