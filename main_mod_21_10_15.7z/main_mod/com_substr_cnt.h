
#ifndef com_substr_cntH
#define com_substr_cntH

int find_common_substr(char *s1, int len1,char *s2, int len2, int k);


#endif